import { Component } from '@angular/core';

@Component({
  selector: 'app-agb',
  standalone: true,
  imports: [],
  templateUrl: './agb.component.html',
  styleUrl: './agb.component.scss'
})
export class AgbComponent {

}
