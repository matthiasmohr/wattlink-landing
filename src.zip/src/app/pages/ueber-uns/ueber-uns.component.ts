import { Component } from '@angular/core';

@Component({
  selector: 'app-ueber-uns',
  standalone: true,
  imports: [],
  templateUrl: './ueber-uns.component.html',
  styleUrl: './ueber-uns.component.scss'
})
export class UeberUnsComponent {

}
